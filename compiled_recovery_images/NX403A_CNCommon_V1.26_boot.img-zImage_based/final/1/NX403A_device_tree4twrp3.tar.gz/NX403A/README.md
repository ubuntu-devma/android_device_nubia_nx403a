Unified Device Tree For Nubia NX403A
========================================
Basic   | Spec Sheet
-------:|:-------------------------
CPU     | Quad-core 1.7 GHz Krait 300
CHIPSET | Qualcomm APQ8064 Snapdragon 600
GPU     | Adreno 300
Memory  | 2GB RAM
Shipped Android Version | 4.2
Storage | 16GB
Battery | Li-Ion 2300 mAh battery
Display | 720 x 1080 pixels, 4.7 inches
Camera  | 13 MP, 4128 x 3096 pixels, autofocus, LED flash

Thanks lwang and others who supported me bring up this device.
