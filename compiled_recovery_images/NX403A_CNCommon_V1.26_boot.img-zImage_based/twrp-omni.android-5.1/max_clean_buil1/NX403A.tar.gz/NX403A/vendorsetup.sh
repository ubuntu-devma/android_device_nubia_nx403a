for i in eng userdebug user; do
	add_lunch_combo omni_NX403A-${i}
done
